package Model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author mingl
 */
public enum Destination {
    DESTINATION_A,
    DESTINATION_B,
    DESTINATION_C
}
